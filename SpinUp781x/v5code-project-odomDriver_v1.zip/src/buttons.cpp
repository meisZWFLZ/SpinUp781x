#include "vex.h"
#include "buttons.h"
#include "robot-config.h"
#include <math.h>

using namespace vex;

void buttonControl() {
  
//   if(Controller1.ButtonL1.pressing()){
//     f_bar_a.spin(reverse, 70, pct);
//     f_bar_b.spin(fwd, 70, pct);
//   }
//   else if (Controller1.ButtonL2.pressing()) {
//     f_bar_a.spin(fwd, 70, pct);
//     f_bar_b.spin(reverse, 70, pct);
//   }
//   else four_bar.stop(hold);
  
//   if (Controller1.ButtonR1.pressing()) {
//     mogo_lift.spin(fwd, 100, pct);
//   }
//   else if (Controller1.ButtonR2.pressing()) {
//     mogo_lift.spin(reverse, 100, pct);
//   }
//   else mogo_lift.stop(hold);
  
//   if (Controller1.ButtonB.pressing()) {
//     clamp.spin(fwd, 70, pct);
//   }
//   else if (Controller1.ButtonX.pressing()) {
//     clamp.spin(reverse, 70, pct);
//   }
//   else clamp.stop(hold);

 }
