using namespace vex;

#ifndef OP_CONTROL_H
#define OP_CONTROL_H

void buttonControl (void);

#endif